package com.example.demo;

import com.example.demo.dao.entities.cours;
import com.example.demo.dao.entities.etudiant;
import com.example.demo.dao.entities.professeur;
import com.example.demo.dao.entities.seance;
import com.example.demo.dao.repositeries.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@SpringBootApplication
public class DemoApplication implements CommandLineRunner {
    @Autowired
    private coursDAO coursDAO;
    @Autowired
    private professeurDAO profDAO;
    @Autowired
    private seanceDAO seancDAO;
    @Autowired
    private etudiantDAO etudDAO;
    @Autowired
    private personneDAO persDAO;
    @Override
    public void run(String... args) throws Exception {

        etudiant etudiant1=new etudiant();
        etudiant1.setNom("salma");
        etudiant1.setDateNaissance(new Date(2002,07,18));
        etudiant1.setMatricule("C2021_000");
        persDAO.save(etudiant1);

        etudiant etudiant2=new etudiant();
        etudiant2.setNom("BST");
        etudiant2.setDateNaissance(new Date(2002,8,18));
        etudiant2.setMatricule("C2031_000");
        persDAO.save(etudiant2);

        professeur prof1 = new professeur();
        prof1.setNom("M.prof");
        prof1.setDateNaissance(new Date(1995,8,13));
        prof1.setD_affectation(new Date(2020,12,12));
        persDAO.save(prof1);


        cours cours1 = new cours();
        cours1.setTitre("JEE");
        cours1.setDescription("Dans ce cours nous etudions JEE");
        coursDAO.save(cours1);

        seance seance1 = new seance();
        seance1.setDate(new Date(2023,06,7));
        seance1.setH_debut(new Date(2023,06,03));
        seance1.setH_fin(new Date(2023,06,14));
        seancDAO.save(seance1);

        seance seance2 = new seance();
        seance2.setDate(new Date(2024,06,7));
        seance2.setH_debut(new Date(2024,06,03));
        seance2.setH_fin(new Date(2024,06,14));
        seancDAO.save(seance2);

        List<seance> seanclist = new ArrayList<>();
        seanclist.add(seance1);
        seanclist.add(seance2);
        List<etudiant> etudlist = new ArrayList<>();
        etudlist.add(etudiant1);
        etudlist.add(etudiant2);

        prof1.setCour(cours1);
        cours1.setProf(prof1);
        cours1.setSeanc(seanclist);
        seance1.setCour(cours1);
        seance2.setCour(cours1);
        seance1.setEtud(etudlist);
        seance2.setEtud(etudlist);
        etudiant1.setSeanc(seanclist);
        etudiant2.setSeanc(seanclist);


        persDAO.save(etudiant1);
        persDAO.save(etudiant2);
        persDAO.save(prof1);
        coursDAO.save(cours1);
        seancDAO.save(seance1);
        seancDAO.save(seance2);

        List<etudiant> listStudents = etudDAO.findAll();
        listStudents.forEach(etudFromList ->{
            System.out.println(etudFromList.toString());
        });
        List<cours> listCourses = coursDAO.findAll();
        listCourses.forEach(courseFromList ->{
            System.out.println(courseFromList.toString());
        });
        List<professeur> listProfessors = profDAO.findAll();
        listProfessors.forEach(professorFromList ->{
            System.out.println(professorFromList.toString());
        });
        List<seance> listSessions = seancDAO.findAll();
        listSessions.forEach(sessionFromList ->{
            System.out.println(sessionFromList.toString());
        });
        //update
        etudiant1.setNom("boustani");
        persDAO.save(etudiant1);
        prof1.setDateNaissance(new Date(1997,12,13));
        persDAO.save(prof1);
        cours1.setDescription("Mise a jour du cours JEE");
        coursDAO.save(cours1);
        seance1.setDate(new Date(2024,06,19));
        seancDAO.save(seance1);
        //Read after update
        List<etudiant> listStudents2 = etudDAO.findAll();
        listStudents2.forEach(studentFromList ->{
            System.out.println(studentFromList.toString());
        });
        List<cours> listCourses2 = coursDAO.findAll();
        listCourses2.forEach(courseFromList ->{
            System.out.println(courseFromList.toString());
        });
        List<professeur> listProfessors2 = profDAO.findAll();
        listProfessors2.forEach(professorFromList ->{
            System.out.println(professorFromList.toString());
        });
        List<seance> listSessions2 = seancDAO.findAll();
        listSessions2.forEach(sessionFromList ->{
            System.out.println(sessionFromList.toString());
        });

        //delete

        coursDAO.deleteById(1);
        try {
            System.out.println(coursDAO.findById(1).get());

        } catch (Exception exception) {
            System.out.println("The course has been deleted");}

        // persDAO.deleteById(1);
        try {
        //    System.out.println(persDAO.findById(1).get());

        } catch (Exception exception) {
            System.out.println("The person has been deleted");}

        seancDAO.deleteById(1);
        try {
            System.out.println(seancDAO.findById(1).get());

        } catch (Exception exception) {
            System.out.println("The session has been deleted");}



    }


    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

}
