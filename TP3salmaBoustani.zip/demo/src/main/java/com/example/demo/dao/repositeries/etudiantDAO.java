package com.example.demo.dao.repositeries;

import com.example.demo.dao.entities.etudiant;
import org.springframework.data.jpa.repository.JpaRepository;

public interface etudiantDAO extends JpaRepository<etudiant,Long> {
}
