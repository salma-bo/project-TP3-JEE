package com.example.demo.dao.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class professeur extends personne {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Date d_affectation;

    @OneToOne(mappedBy = "prof")
    private cours cour;

    @Override
    public String toString() {
        return "professeur{" +
                "d_affectation=" + d_affectation +
                ", cour=" + cour +
                "} " + super.toString();
    }
}
