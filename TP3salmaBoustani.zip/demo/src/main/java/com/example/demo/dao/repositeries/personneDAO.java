package com.example.demo.dao.repositeries;

import com.example.demo.dao.entities.personne;
import org.springframework.data.jpa.repository.JpaRepository;

public interface personneDAO extends JpaRepository<personne,Long> {
}
