package com.example.demo.dao.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class seance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer Id;
    private Date date;
    private Date h_debut;
    private Date h_fin;

    @ManyToOne
    private cours cour;

    @ManyToMany(fetch = FetchType.EAGER)
    private Collection<etudiant> etud = new ArrayList<>();

    @Override
    public String toString() {
        return "seance{" +
                "Id=" + Id +
                ", date=" + date +
                ", h_debut=" + h_debut +
                ", h_fin=" + h_fin +
                ", etud=" + etud +
                '}';
    }
}
