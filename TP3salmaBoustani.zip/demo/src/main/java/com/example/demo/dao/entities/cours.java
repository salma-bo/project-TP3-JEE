package com.example.demo.dao.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collection;
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class cours {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer Id;
    private String titre;
    private String description;

    @OneToOne(mappedBy = "cour")
    private professeur prof;

    @OneToMany(mappedBy = "cour", fetch = FetchType.LAZY)
    private Collection<seance> seanc;

    @Override
    public String toString() {
        return "cours{" +
                "Id=" + Id +
                ", titre='" + titre + '\'' +
                ", description='" + description + '\'' +
                ", prof=" + prof +
                '}';
    }
}