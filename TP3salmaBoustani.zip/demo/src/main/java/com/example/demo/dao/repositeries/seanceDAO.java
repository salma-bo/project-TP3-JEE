package com.example.demo.dao.repositeries;

import com.example.demo.dao.entities.seance;
import org.springframework.data.jpa.repository.JpaRepository;

public interface seanceDAO extends JpaRepository<seance,Integer> {
}
