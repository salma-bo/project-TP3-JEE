package com.example.demo.dao.repositeries;

import com.example.demo.dao.entities.cours;
import org.springframework.data.jpa.repository.JpaRepository;

public interface coursDAO extends JpaRepository<cours,Integer> {
}
