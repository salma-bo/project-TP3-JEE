package com.example.demo.dao.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Collection;
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class etudiant extends personne {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String matricule;

    @ManyToMany(mappedBy = "etud", fetch = FetchType.EAGER)
    private Collection<seance> seanc = new ArrayList<>();

    @Override
    public String toString() {
        return "etudiant{" +
                "matricule='" + matricule + '\'' +
                ", seanc=" + seanc +
                "} " + super.toString();
    }
}
